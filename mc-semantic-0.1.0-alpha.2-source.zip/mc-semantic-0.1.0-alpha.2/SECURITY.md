# Security Policy

The project is pre-release research software.

Please do not use it for security-critical binary transformation in production until a stable release explicitly states that the relevant subsystem is supported.

Report security-sensitive issues privately through the repository's configured GitHub security reporting mechanism once enabled.

The development policy requires checked arithmetic, deterministic failures, sanitizer testing, fuzzing and release provenance before stable 1.0.
