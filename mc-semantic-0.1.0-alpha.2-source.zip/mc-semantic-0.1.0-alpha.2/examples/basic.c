/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"
#include <stdio.h>

int main(void) {
    const mc_constraint rel8 = {
        .width = 8U,
        .granularity = 1U,
        .min = -128,
        .max = 127,
        .signed_value = true
    };

    const int64_t delta = 127;
    printf("constraint: %s\n", mc_status_name(mc_constraint_check(&rel8, delta)));
    return 0;
}
