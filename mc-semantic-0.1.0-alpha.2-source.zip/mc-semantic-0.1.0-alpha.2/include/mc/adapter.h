/* SPDX-License-Identifier: MIT */
#ifndef MC_ADAPTER_H
#define MC_ADAPTER_H

#include <stddef.h>
#include <stdint.h>

#include "mc.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Experimental adapter interface. Not part of the stable M0 ABI. */
typedef struct {
    const char *name;
    uint32_t major;
    uint32_t minor;
    uint32_t patch;
} mc_adapter_info;

typedef struct {
    mc_status (*identify_reference)(const mc_context *context,
                                    const mc_byte_view *bytes,
                                    uint64_t address,
                                    mc_reference *reference,
                                    mc_realization *realization);

    mc_status (*validate_realization)(const mc_context *context,
                                      const mc_realization *realization);
} mc_adapter;

#ifdef __cplusplus
}
#endif

#endif
