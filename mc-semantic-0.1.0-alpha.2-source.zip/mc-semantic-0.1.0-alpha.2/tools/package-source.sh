#!/bin/sh
set -eu

VERSION="$(cat VERSION)"
ARCHIVE="mc-semantic-${VERSION}-source.zip"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT INT TERM

PREFIX="mc-semantic-${VERSION}"
mkdir -p "$TMP/$PREFIX"

git archive --format=tar --prefix="$PREFIX/" HEAD | tar -xf - -C "$TMP"
rm -rf "$TMP/$PREFIX/.git"

(cd "$TMP" && zip -qr "${ARCHIVE}" "$PREFIX")
cp "$TMP/$ARCHIVE" .
printf '%s\n' "$ARCHIVE"
