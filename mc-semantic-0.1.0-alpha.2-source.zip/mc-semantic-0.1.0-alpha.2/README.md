# Machine-Code Reference & Realization Core

> Research/engineering project: a small, architecture-neutral semantic layer for machine-code references, encoding realizations, coupled reference groups, representability constraints, and code-location mappings.

**Status:** pre-release research implementation

The project does **not** attempt to replace LLVM, Iced, Zydis, GNU binutils, GTIRB, BOLT, an assembler, a linker, or a full binary rewriter. Architecture-specific decoding/encoding and object-format semantics remain in adapters.

## Current scope

The initial implementation targets a deliberately small semantic core:

- `mc_context`
- `mc_region`
- `mc_target`
- `mc_expression`
- `mc_reference`
- `mc_reference_group`
- `mc_realization`
- `mc_constraint`
- `mc_address_map`
- `mc_status`

Transformation planning, architecture adapters, and conformance tooling are separate layers.

## Build

```sh
cmake -S . -B build -DMC_BUILD_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
cmake --install build --prefix "$PWD/install"
```

## Documentation

Material for MkDocs is included from the beginning:

```sh
python -m venv .venv
. .venv/bin/activate
pip install -r docs/requirements.txt
mkdocs serve
```

## Version

The first research implementation is `0.1.0-alpha.2`. Versioning follows Semantic Versioning for the eventual public release line; pre-1.0 releases may change APIs as the M0 experiments falsify or refine the model. citeturn364519search0

See [`docs/roadmap/versioning.md`](docs/roadmap/versioning.md).

## Releases and source ZIPs

The Git tag is the authoritative version identity. Each public release can also be uploaded manually as a matching source ZIP asset, e.g. `mc-semantic-0.1.0-alpha.2-source.zip`. See `docs/development/release-artifacts.md` and `docs/development/github-upload.md`.
