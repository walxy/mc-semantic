/* SPDX-License-Identifier: MIT */
#include <stdio.h>

void test_constraints(void);
void test_expressions(void);
void test_address_map(void);

int main(void) {
    test_constraints();
    test_expressions();
    test_address_map();
    puts("all tests passed");
    return 0;
}
