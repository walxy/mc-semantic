/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"
#include <assert.h>
#include <stdint.h>

void test_address_map(void) {
    mc_address_map map;
    mc_address_map_init(&map);

    assert(mc_address_map_add(&map, (mc_map_entry){
        .old_region = { .address = 0x1000U, .size = 0x20U },
        .new_region = { .address = 0x8000U, .size = 0x20U },
        .state = MC_MAP_MOVED
    }) == MC_STATUS_OK);

    uint64_t translated = 0U;
    assert(mc_address_map_translate_exact(&map, 0x1008U, &translated) == MC_STATUS_OK);
    assert(translated == 0x8008U);

    assert(mc_address_map_add(&map, (mc_map_entry){
        .old_region = { .address = 0x1010U, .size = 0x20U },
        .new_region = { .address = 0x9000U, .size = 0x20U },
        .state = MC_MAP_MOVED
    }) == MC_STATUS_CONFLICT);

    assert(mc_address_map_add(&map, (mc_map_entry){
        .old_region = { .address = UINT64_MAX, .size = 2U },
        .new_region = { .address = 0U, .size = 2U },
        .state = MC_MAP_MOVED
    }) == MC_STATUS_INVALID);

    assert(mc_address_map_add(&map, (mc_map_entry){
        .old_region = { .address = 0x2000U, .size = 0x10U },
        .new_region = { .address = 0U, .size = 0U },
        .state = MC_MAP_DELETED
    }) == MC_STATUS_OK);
    assert(mc_address_map_translate_exact(&map, 0x2008U, &translated) == MC_STATUS_UNSUPPORTED);

    mc_address_map_destroy(&map);
}
