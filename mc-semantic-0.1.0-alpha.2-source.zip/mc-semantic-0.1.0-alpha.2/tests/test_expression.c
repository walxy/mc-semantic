/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"
#include <assert.h>
#include <stdint.h>

void test_expressions(void) {
    int64_t value = 0;

    const mc_expression pc = {
        .kind = MC_EXPR_PC_RELATIVE,
        .addend = 0,
        .page_shift = 0U
    };
    assert(mc_expression_eval(&pc, 1000U, 1100U, &value) == MC_STATUS_OK);
    assert(value == 100);
    assert(mc_expression_eval(&pc, 1100U, 1000U, &value) == MC_STATUS_OK);
    assert(value == -100);

    const mc_expression next_pc = {
        .kind = MC_EXPR_NEXT_PC_RELATIVE,
        .addend = -4,
        .page_shift = 0U
    };
    assert(mc_expression_eval(&next_pc, 1004U, 1100U, &value) == MC_STATUS_OK);
    assert(value == 92);

    const mc_expression page = {
        .kind = MC_EXPR_PAGE_RELATIVE,
        .addend = 0,
        .page_shift = 12U
    };
    assert(mc_expression_eval(&page, 0x1000U, 0x9000U, &value) == MC_STATUS_OK);
    assert(value == 8);

    const mc_expression page_addend = {
        .kind = MC_EXPR_PAGE_RELATIVE,
        .addend = -1,
        .page_shift = 12U
    };
    assert(mc_expression_eval(&page_addend, 0x9000U, 0x9000U, &value) == MC_STATUS_OK);
    assert(value == -1);

    const mc_expression add_overflow = {
        .kind = MC_EXPR_PC_RELATIVE,
        .addend = 1,
        .page_shift = 0U
    };
    assert(mc_expression_eval(&add_overflow, 0U, UINT64_MAX, &value) == MC_STATUS_OUT_OF_RANGE);

    const mc_expression section = {
        .kind = MC_EXPR_SECTION_RELATIVE,
        .addend = 0,
        .page_shift = 0U
    };
    assert(mc_expression_eval(&section, 0U, 0U, &value) == MC_STATUS_UNSUPPORTED);
}
