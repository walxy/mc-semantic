# Changelog

## [0.1.0-alpha.2] - 2026-08-30

### Changed

- Correct explicit next-PC expression semantics.
- Correct signed 63-bit constraint validation.
- Correct page-relative addend evaluation.
- Strengthen address-map overlap and overflow handling.
- Add experimental adapter contract marker and release-artifact documentation.

### Not included

- Architecture-specific adapters
- Binary relocation/transformation
- Process-memory patching


## [0.1.0-alpha.1] - 2026-08-30

### Added

- Initial C11 semantic core scaffold.
- Checked representability constraints.
- Small normalized address-expression evaluator.
- Basic semantic address map.
- Material for MkDocs documentation from project start.
- CMake build, tests and GitHub Actions CI.

### Explicitly not included

- architecture adapters
- binary relocation
- transformation planning
- process-memory patching
- DWARF/CFI/ABI rewriting
