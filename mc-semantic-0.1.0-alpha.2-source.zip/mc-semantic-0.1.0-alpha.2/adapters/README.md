# Architecture adapters

Architecture adapters translate decoder/linker facts into the neutral M0 model.

They are intentionally outside `src/` so that the semantic core does not gain
architecture-specific dependencies.

Planned adapters:

- `x86_64/` — selected relative branches/calls and RIP-relative references.
- `aarch64/` — selected branch/address-reference realizations.
- `riscv64/` — selected JAL/branch and grouped PC-relative realizations.

An adapter may depend on LLVM, Iced, Zydis, GNU/binutils, or another established
engine. `mc-core` does not.
