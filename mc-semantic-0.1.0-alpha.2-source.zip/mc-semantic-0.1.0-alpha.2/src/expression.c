/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"

#include <limits.h>
#include <stdbool.h>

static bool add_u64_i64_checked(uint64_t value, int64_t addend, uint64_t *out) {
    if (addend >= 0) {
        const uint64_t uadd = (uint64_t)addend;
        if (value > UINT64_MAX - uadd) return false;
        *out = value + uadd;
        return true;
    }

    /* -(INT64_MIN) cannot be represented as int64_t, so use a safe magnitude calculation. */
    const uint64_t magnitude = (uint64_t)(-(addend + 1)) + UINT64_C(1);
    if (value < magnitude) return false;
    *out = value - magnitude;
    return true;
}

static bool sub_u64_to_i64_checked(uint64_t lhs, uint64_t rhs, int64_t *out) {
    if (lhs >= rhs) {
        const uint64_t d = lhs - rhs;
        if (d > (uint64_t)INT64_MAX) return false;
        *out = (int64_t)d;
        return true;
    }

    const uint64_t d = rhs - lhs;
    if (d > (uint64_t)INT64_MAX + UINT64_C(1)) return false;
    if (d == (uint64_t)INT64_MAX + UINT64_C(1)) {
        *out = INT64_MIN;
        return true;
    }
    *out = -(int64_t)d;
    return true;
}

static uint64_t floor_page(uint64_t address, uint32_t page_shift) {
    return address >> page_shift;
}

mc_status mc_expression_eval(const mc_expression *expression,
                             uint64_t base_address,
                             uint64_t target_address,
                             int64_t *result) {
    if (expression == NULL || result == NULL) {
        return MC_STATUS_INVALID;
    }

    uint64_t adjusted_target = target_address;
    if (!add_u64_i64_checked(target_address, expression->addend, &adjusted_target)) {
        return MC_STATUS_OUT_OF_RANGE;
    }

    switch (expression->kind) {
    case MC_EXPR_PC_RELATIVE:
    case MC_EXPR_NEXT_PC_RELATIVE:
        if (!sub_u64_to_i64_checked(adjusted_target, base_address, result)) {
            return MC_STATUS_OUT_OF_RANGE;
        }
        return MC_STATUS_OK;

    case MC_EXPR_PAGE_RELATIVE: {
        if (expression->page_shift >= 64U) {
            return MC_STATUS_INVALID;
        }
        const uint64_t base_page = floor_page(base_address, expression->page_shift);
        const uint64_t target_page = floor_page(adjusted_target, expression->page_shift);
        if (!sub_u64_to_i64_checked(target_page, base_page, result)) {
            return MC_STATUS_OUT_OF_RANGE;
        }
        return MC_STATUS_OK;
    }

    case MC_EXPR_SECTION_RELATIVE:
        return MC_STATUS_UNSUPPORTED;

    default:
        return MC_STATUS_INVALID;
    }
}
