/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"

const char *mc_status_name(mc_status status) {
    switch (status) {
    case MC_STATUS_OK: return "OK";
    case MC_STATUS_INVALID: return "INVALID";
    case MC_STATUS_UNRESOLVED: return "UNRESOLVED";
    case MC_STATUS_AMBIGUOUS: return "AMBIGUOUS";
    case MC_STATUS_OUT_OF_RANGE: return "OUT_OF_RANGE";
    case MC_STATUS_UNSUPPORTED: return "UNSUPPORTED";
    case MC_STATUS_CONFLICT: return "CONFLICT";
    default: return "UNKNOWN_STATUS";
    }
}
