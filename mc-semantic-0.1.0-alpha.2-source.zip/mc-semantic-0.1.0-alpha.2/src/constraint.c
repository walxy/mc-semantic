/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"

static bool signed_width_bounds(uint32_t width, int64_t *min_value, int64_t *max_value) {
    if (width == 0U || width > 64U || min_value == NULL || max_value == NULL) {
        return false;
    }

    if (width == 64U) {
        *min_value = INT64_MIN;
        *max_value = INT64_MAX;
        return true;
    }

    const uint32_t shift = width - 1U;
    const int64_t half = INT64_C(1) << shift;
    *min_value = -half;
    *max_value = half - INT64_C(1);
    return true;
}

mc_status mc_constraint_check(const mc_constraint *constraint, int64_t value) {
    if (constraint == NULL || constraint->width == 0U || constraint->width > 64U ||
        constraint->granularity == 0U) {
        return MC_STATUS_INVALID;
    }

    if (constraint->min > constraint->max) {
        return MC_STATUS_INVALID;
    }

    if (value < constraint->min || value > constraint->max) {
        return MC_STATUS_OUT_OF_RANGE;
    }

    const int64_t granularity = (int64_t)constraint->granularity;
    if ((value % granularity) != 0) {
        return MC_STATUS_OUT_OF_RANGE;
    }

    if (constraint->signed_value) {
        int64_t signed_min = 0;
        int64_t signed_max = 0;
        if (!signed_width_bounds(constraint->width, &signed_min, &signed_max)) {
            return MC_STATUS_INVALID;
        }
        if (value < signed_min || value > signed_max) {
            return MC_STATUS_OUT_OF_RANGE;
        }
    }

    return MC_STATUS_OK;
}
