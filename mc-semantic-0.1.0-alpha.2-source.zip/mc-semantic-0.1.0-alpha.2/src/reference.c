/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"

/* M0 deliberately keeps reference validation minimal. Architecture adapters
 * are responsible for deriving the reference facts from decoded instructions. */
