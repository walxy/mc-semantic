# Code of Conduct

Contributors are expected to communicate professionally, focus on technical evidence, and treat others with respect. Project maintainers may moderate discussions that do not follow these expectations.
