# System architecture

```text
Existing decoder/linker/IR
          |
          v
   architecture adapter
          |
          v
   -------------------
      mc semantic core
   -------------------
   MCReference
   MCExpression
   MCRealization
   MCReferenceGroup
   MCConstraint
   MCAddressMap
          |
          v
      mc-transform
   MCRewrite
   MCReferenceChange
   MCTransformPlan
   MCTransformReport
          |
          v
      conformance/tooling
```

The core is deliberately below transformation policy and above raw architecture-specific encoding facts.
