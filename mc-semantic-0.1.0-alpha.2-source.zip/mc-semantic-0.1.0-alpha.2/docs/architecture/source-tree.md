# Source tree

```text
.
├── .github/
│   └── workflows/                 # CI and documentation deployment
├── adapters/                      # architecture/engine adapters (not core)
├── docs/                          # Material for MkDocs
│   ├── architecture/
│   ├── decisions/
│   ├── development/
│   ├── faq/
│   ├── guides/
│   ├── roadmap/
│   └── spec/
├── examples/                     # tiny user-facing examples
├── include/mc/                   # public C11 API; experimental adapter marker
├── release-notes/                # exact release title/notes prepared for GitHub
├── src/                          # dependency-free semantic core
├── tests/                        # deterministic unit tests and future fixtures
├── tools/                        # release/archive helpers; not runtime code
├── CMakeLists.txt
├── CHANGELOG.md
├── LICENSE
├── README.md
├── SECURITY.md
├── VERSION
└── mkdocs.yml
```

Architecture adapters must not be placed under `src/`; this prevents the core from acquiring architecture-specific dependencies.
