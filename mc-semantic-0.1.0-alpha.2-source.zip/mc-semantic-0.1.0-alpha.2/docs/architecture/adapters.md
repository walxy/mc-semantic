# Core versus adapters

## Core owns

- logical references
- normalized address expressions
- realization records
- coupled groups
- representability constraints
- location mappings
- explicit status values

## Adapters own

- instruction decoding/encoding
- architecture-specific bitfields
- relocation/fixup identifiers
- ELF/COFF/Mach-O semantics
- ABI/code-model policy
- TLS/GOT/PLT rules
- assembler syntax

This boundary prevents the project from becoming a miniature linker/backend.
