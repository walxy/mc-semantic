# C API

The initial API is intentionally small. Public declarations are currently in `include/mc/mc.h`.

## Checked constraint

```c
mc_status mc_constraint_check(const mc_constraint *constraint, int64_t value);
```

## Expression evaluation

```c
mc_status mc_expression_eval(const mc_expression *expression,
                             uint64_t base_address,
                             uint64_t target_address,
                             int64_t *result);
```

## Address mapping

```c
void mc_address_map_init(mc_address_map *map);
void mc_address_map_destroy(mc_address_map *map);
mc_status mc_address_map_add(mc_address_map *map, mc_map_entry entry);
mc_status mc_address_map_translate_exact(const mc_address_map *map,
                                         uint64_t old_address,
                                         uint64_t *new_address);
```

The public API is experimental until the M0 conformance suite is complete.

### Important M0 rule

The expression evaluator receives the **actual base address**. The core does not infer “next instruction” by assuming a fixed instruction size. This is required for variable-length ISAs such as x86-64. An architecture adapter/realization supplies the appropriate base address.
