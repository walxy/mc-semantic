# FAQ

## Is this another relocator?

No. Existing engines already perform architecture-specific relocation and relaxation. The proposed layer normalizes the semantic information those systems manipulate.

## Is it a binary rewriter?

Not in M0. Transformation planning is a separate layer and is initially experimental.

## Does it replace LLVM/Iced/Zydis/GNU?

No. Those systems remain important implementations/adapters.

## Why have `MCReferenceGroup`?

Because real systems contain coupled reference components. The current RISC-V linker-relaxation specification explicitly defines relocation groups and requires group-consistent relaxation. citeturn830869search1

## Why is `MCAddressMap` separate from metadata?

A location map tells consumers how code locations changed. A DWARF/CFI/profiler consumer must still understand its own format semantics.

## Why not a generic linker-expression AST?

That would duplicate mature linker infrastructure. M0 intentionally defines a small closed expression vocabulary.

## Is the core written in assembly language?

No. The recommended implementation language for the core is portable **C11**, not assembly. Assembly is appropriate for architecture-specific test fixtures and, where unavoidable, tiny performance/ABI probes—not for the semantic core.
