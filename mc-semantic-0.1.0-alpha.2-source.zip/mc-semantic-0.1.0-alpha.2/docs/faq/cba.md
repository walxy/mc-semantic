# CBA — code-base architecture and language choice

## Should MC be fully written in assembly language?

No. The recommended design is a portable C11 semantic core with architecture-specific adapters and assembly fixtures.

### C11 core

The core performs:

- checked integer arithmetic;
- constraint validation;
- normalized expression evaluation;
- reference/group data modeling;
- address-map bookkeeping.

These operations do not benefit from being handwritten in assembly in the absence of measured profiling evidence.

### Assembly

Assembly remains appropriate for:

- exact instruction-encoding fixtures;
- ABI experiments;
- architecture regression cases;
- measured hot-path routines, if a later profile proves one necessary.

### Existing engines

The adapters should reuse established decoders/encoders such as LLVM, Iced, or Zydis rather than reimplementing them.

The intended structure is:

```text
existing decoder / assembler / linker facts
                    |
                    v
          architecture adapter
                    |
                    v
              C11 mc core
                    |
                    v
            transformation layer
```

This gives the project portability without pretending that one library should replace the existing toolchain ecosystem.
