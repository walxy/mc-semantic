# Machine-Code Reference & Realization Core

`mc-semantic` is a research implementation of a small architecture-neutral model for machine-code references and their physical realizations.

## Why it exists

Existing systems already provide excellent instruction decoding, encoding, relocation, linker relaxation and binary rewriting. This project intentionally sits at a narrower boundary: normalize the relationship between a source location, a logical target, an address expression, an encoding realization, coupled reference groups, constraints, and old/new code locations.

## Current status

**0.1.0-alpha.1 — research/developer preview.**

The current release is useful for experimentation with the core arithmetic and address-map primitives. It is **not** yet a general binary relocator or production-safe transformation engine.

## Design rule

> The core models relationships and constraints; architecture adapters model encodings and object-format semantics.

## Supported research architectures

The specification is being tested against:

- x86-64
- AArch64
- RISC-V RV64

The current C implementation intentionally contains only the architecture-neutral primitives. Adapters will follow the conformance work.
