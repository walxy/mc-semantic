# Versioning and change policy

The eventual public API follows Semantic Versioning 2.0.0: `MAJOR.MINOR.PATCH`, with pre-release identifiers such as `0.1.0-alpha.1`. Pre-1.0 development deliberately reserves the right to change the API as empirical work falsifies assumptions.

## Meaning of versions before 1.0

| Version change | Meaning during M0/M1 |
|---|---|
| alpha patch (`0.1.0-alpha.1` → `alpha.2`) | Bug fix, test correction, documentation correction; no intentional semantic-model change |
| alpha minor (`0.1.0-alpha` → `0.2.0-alpha`) | New experimental module or model refinement that may still break APIs |
| beta patch | Correctness/security fixes only, barring explicitly documented compatibility exception |
| beta minor | New backwards-compatible capability within the beta contract |
| `0.x` major/minor | Breaking experimental API/model change; explicitly documented |
| `1.x` minor | Backwards-compatible public API feature |
| `1.x` patch | Backwards-compatible bug/security/documentation correction |
| `2.0.0` | Intentional stable API/semantic incompatibility |

Semantic Versioning itself defines the normal MAJOR/MINOR/PATCH rules; the project adds the explicit pre-1.0 research policy above. citeturn364519search0
