# Development release roadmap

The roadmap is capability-driven. Version numbers are used to make even small but meaningful changes traceable.

| Version | Planned change | User-facing status |
|---|---|---|
| `0.1.0-alpha.1` | Initial semantic prototype | obsolete research snapshot |
| `0.1.0-alpha.2` | Defensive arithmetic/map corrections, adapter marker, release packaging | current correction release |
| `0.1.0-alpha.3` | x86-64 experimental adapter | first machine-code user release |
| `0.1.0-alpha.4` | AArch64 experimental adapter | cross-ISA research |
| `0.1.0-alpha.5` | RISC-V experimental adapter/group cases | three-ISA research |
| `0.1.0-beta.1` | Freeze M0 semantic contract and publish conformance corpus | serious specialist integration |
| `0.1.0-beta.2` | Differential conformance reports | validation tooling |
| `0.1.0-beta.3` | Experimental transformation planning | prototype only |
| `0.1.0-rc.1` | Release hardening | release candidate |
| `0.1.0` | First recommended developer release | stable M0 semantics |
| `0.2.0` | First supported integration family | conditional |
| `0.3.0` | Controlled transformation subset | conditional |
| `0.4.0` | Expanded conformance | conditional |
| `0.5.0` | Patch-window utility | conditional |
| `0.6.0` | Optional metadata adapters | experimental |
| `0.7.0` | Security/provenance maturity | hardening |
| `0.8.0` | API hardening | pre-1.0 stabilization |
| `0.9.0` | Feature freeze candidate | stabilization |
| `1.0.0` | Stable semantic core | production foundation |

No milestone is automatic: a version is released only when its acceptance gates pass.
