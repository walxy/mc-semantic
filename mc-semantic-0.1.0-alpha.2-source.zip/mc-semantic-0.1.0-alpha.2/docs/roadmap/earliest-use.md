# Earliest possible user availability

“Usable” has different meanings for this project.

| Level | Release target | What users can do | Confidence |
|---|---|---|---|
| Research core | `0.1.0-alpha.2` | Use checked constraints, normalized expressions and basic address maps | High |
| First machine-code adapter | `0.1.0-alpha.3` | Normalize a selected x86-64 reference subset | Medium |
| Cross-ISA specialist integration | `0.1.0-beta.1` | Consume the frozen M0 semantic model across x86-64/AArch64/RISC-V | Conditional on conformance |
| Recommended developer use | `0.1.0` | Build research/integration tooling against documented M0 API | Conditional on beta/RC gates |
| Controlled transformation use | `0.2.x–0.3.x` | Use a defined transformation subset if conformance/security gates pass | Not guaranteed |
| General binary rewriting | Not promised | Existing rewriters/linkers remain outside scope | N/A |

## Earliest possible answer

**Today’s alpha is already usable as a dependency-free semantic library**, but not as an arbitrary binary relocator.

The earliest useful release for *machine-code consumers* is expected to be `0.1.0-alpha.3`, when the first narrow x86-64 adapter exists.

The earliest release I would recommend for a broader specialist integration is `0.1.0-beta.1`, after the three-architecture M0 corpus and adapter contract are validated.

The project must not describe `0.1.0-alpha.*` as a production binary rewriter.
