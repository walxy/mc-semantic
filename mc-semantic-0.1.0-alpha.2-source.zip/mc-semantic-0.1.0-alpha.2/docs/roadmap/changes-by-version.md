# Changes by version

| Version | Change policy |
|---|---|
| `0.1.0-alpha.1` | Initial semantic core scaffold |
| `0.1.0-alpha.2` | Defensive validation and diagnostics |
| `0.1.0-alpha.3` | x86-64 experimental reference adapter |
| `0.1.0-alpha.4` | AArch64 experimental reference adapter |
| `0.1.0-alpha.5` | RISC-V experimental reference/group adapter |
| `0.1.0-beta.1` | M0 semantic freeze candidate |
| `0.1.0-beta.2` | Differential conformance |
| `0.1.0-beta.3` | Experimental transformation planning |
| `0.1.0-rc.1` | Release hardening |
| `0.1.0` | First recommended developer release |
| `0.2.0` | First useful integration release |
| `0.3.0` | Controlled transformation subset |
| `0.4.0` | Expanded conformance |
| `0.5.0` | Patch-window utility |
| `0.6.0` | Metadata adapter experiments |
| `0.7.0` | Security/reproducibility maturity |
| `0.8.0` | API hardening |
| `0.9.0` | Feature-freeze candidate |
| `1.0.0` | Stable semantic core |

Minor changes in the `0.x` series are explicitly allowed to contain API/model refinements because the semantic contract is still experimental.
