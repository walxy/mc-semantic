# User scenarios

## Scenario 1 — Research-only user

A researcher wants to compare how three tools describe the same relative reference.

Use `0.1.0-alpha.1` for the core arithmetic and mapping primitives, then add the experimental adapters as they land.

## Scenario 2 — Specialist machine-code tool

A post-link optimizer needs to decide whether a candidate realization still fits after code movement.

The adapter supplies the logical reference, explicit base address, realization constraints and any coupled group. The core checks the expression and constraints; the transformation layer records the rewrite.

## Scenario 3 — Metadata consumer

A DWARF consumer needs to update code addresses after transformation.

It uses `MCAddressMap` to obtain code-location correspondence, then applies DWARF-specific interpretation. The core itself does not parse or rewrite DWARF.

## Scenario 4 — Inline hook tooling

A patching framework needs an instruction-complete window.

`MCPatchWindow` can eventually provide the boundary utility, while the actual machine-code encoder/rewriter remains an external engine. This avoids making the core a process-memory patcher.
