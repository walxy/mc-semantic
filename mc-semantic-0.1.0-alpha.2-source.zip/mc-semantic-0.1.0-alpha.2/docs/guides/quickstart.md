# Quick start

The first release exposes checked arithmetic and address-map primitives.

```c
#include <mc/mc.h>

mc_constraint rel8 = {
    .width = 8,
    .granularity = 1,
    .min = -128,
    .max = 127,
    .signed_value = true
};

mc_status s = mc_constraint_check(&rel8, 127);
```

For a production transformation, the architecture adapter must first derive the logical reference and candidate realization. The core then evaluates the expression and checks the realization's constraints.
