# Installation

## Build the C library

Requirements:

- C11 compiler
- CMake 3.20 or newer

GCC has substantially complete C11 support and accepts `-std=c11`. citeturn787336search0turn787336search1

```sh
cmake -S . -B build -DMC_BUILD_TESTS=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
cmake --install build --prefix "$PWD/install"
```

## Build documentation

Material for MkDocs can be installed with pip; the project recommends a virtual environment, and its documentation recommends constraining upgrades to the current major version when reproducibility matters. citeturn787336search6

```sh
python -m venv .venv
. .venv/bin/activate
pip install -r docs/requirements.txt
mkdocs serve
```

## GitHub Pages

The repository contains a GitHub Actions workflow using `mkdocs gh-deploy`. Material for MkDocs documents GitHub Pages deployment through a `gh-pages` branch, and also documents GitHub Actions based deployment. citeturn787336search5
