# Specification overview

## Semantic layers

The M0 model has three primary semantic levels:

1. **Logical reference** — what machine-code relationship exists?
2. **Realization** — how is that relationship encoded?
3. **Constraint** — when is that realization representable?

Transformation changes the realization while preserving the logical relationship when preservation is required.

## Core types

| Type | Responsibility |
|---|---|
| `MCContext` | Architecture/mode context |
| `MCRegion` | Addressed region without ownership of bytes |
| `MCTarget` | Logical destination/location |
| `MCExpression` | Small normalized address expression |
| `MCReference` | Source/target relationship |
| `MCReferenceGroup` | Coupled reference components |
| `MCRealization` | Physical encoding representation |
| `MCConstraint` | Encoding representability |
| `MCAddressMap` | Old/new location mapping |
| `MCStatus` | Explicit result state |
