# M0 traceability

| Requirement | Evidence / rationale | M0 implementation status |
|---|---|---|
| Relative references use an explicit base | x86-64 uses a base tied to the encoded instruction; AArch64/RISC-V use different PC-relative forms | Implemented in expression API |
| Encoding range is separate from logical reference | LLVM exposes target-specific fixups; Iced exposes relocation results | Model frozen |
| Coupled references are explicit | RISC-V linker-relaxation specification defines relocation groups; AArch64 LLD checks paired relaxations | Model frozen, adapters pending |
| Page-relative semantics remain distinct | AArch64 `ADRP` uses page-relative computation | Model frozen |
| No silent narrowing | RISC-V LLVM backend checks JAL/branch range before encoding | Unit tests implemented |
| Address map is not arbitrary byte interpolation | Transformation of instruction sequences may change sizes/forms | M0 implementation only translates same-size moves |
| Metadata remains adapter-specific | Current BOLT issues show code-address rewriting inside DWARF expressions requires DWARF-aware handling | Explicit non-goal |
