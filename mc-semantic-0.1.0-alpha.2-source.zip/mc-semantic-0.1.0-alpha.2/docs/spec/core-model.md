# Core model

## `MCReference`

A reference identifies a source, a logical target, and a normalized address expression. It does not contain an opcode, ELF relocation ID, encoding width, signedness or ABI policy.

## `MCRealization`

A realization describes the concrete instruction sequence and reference components used to encode the logical reference. Width, granularity and range constraints belong here.

## `MCReferenceGroup`

A group represents coupled reference components whose semantics or transformation behavior are linked. RISC-V's current linker-relaxation specification explicitly defines relocation groups and requires a group to receive consistent relaxation treatment; it gives partial relaxation as a source of possible incorrect execution. citeturn830869search1

LLVM's current AArch64 relaxer independently checks paired relocation/instruction conditions before applying an `ADRP + ADD` relaxation, which is evidence for the same higher-level grouping idea. citeturn830869search7

## `MCConstraint`

A constraint is about representability of a particular realization, not about the logical reference itself. The core must check range and encoding granularity before narrowing a value.

LLVM's current RISC-V backend explicitly checks JAL and conditional-branch ranges and 2-byte fixup alignment, which is why M0 calls this property `granularity` rather than treating it as universal architectural instruction alignment. citeturn830869search0

## `MCExpression`

M0 intentionally uses a closed set of address-expression kinds instead of a general linker expression AST:

- absolute
- PC-relative
- page-relative
- section-relative

The implementation should reject unsupported expression forms instead of silently approximating them.

### Base-address discipline

A relative expression is evaluated against an explicit base address. The semantic core must not infer the base from an instruction address because instruction length is architecture- and encoding-dependent. For x86-64, an adapter supplies the address after the encoded instruction when that is the required architectural PC base.

### Expression evaluation rule

M0 evaluates relative expressions against an **explicit base address** supplied by the adapter/realization. The core never infers an instruction's end address from its start address.

For `MC_EXPR_PC_RELATIVE`, M0 evaluates `target + addend - base` with checked unsigned-address arithmetic followed by checked signed conversion.

For `MC_EXPR_PAGE_RELATIVE`, M0 evaluates `Page(target + addend) - Page(base)`. The page size is `2^page_shift`.

`MC_EXPR_SECTION_RELATIVE` is reserved for a later object-format adapter and currently returns `MC_STATUS_UNSUPPORTED`.
