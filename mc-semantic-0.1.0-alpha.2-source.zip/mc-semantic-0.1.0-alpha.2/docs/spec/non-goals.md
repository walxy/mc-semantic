# Non-goals

The M0 core does not implement:

- an assembler
- a disassembler
- a linker
- an object-file parser
- a generic relocator
- a binary IR
- whole-program equivalence checking
- DWARF rewriting
- CFI rewriting
- ABI validation
- process-memory patching
- globally optimal layout/relaxation

Existing tools remain responsible for those domains. Iced already provides x86 block encoding and relocation-related outputs; Zydis exposes detailed x86 instruction/operand metadata; LLVM provides mature target-specific fixup/relaxation infrastructure. citeturn830869search4turn830869search5turn830869search0
