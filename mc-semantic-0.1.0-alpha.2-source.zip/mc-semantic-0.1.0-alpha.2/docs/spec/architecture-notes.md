# Architecture notes for M0

## x86-64

The core must treat the PC base as supplied by the realization/adapter. A variable-length instruction means the core cannot derive the post-instruction PC from the instruction address alone.

LLVM's x86 backend contains explicit branch relaxation logic for signed 8-bit branches and layout/bundling effects. citeturn830869search8

Iced's `BlockEncoderResult` exposes relocation information and new instruction offsets after block encoding, including rewritten instructions. citeturn830869search4

Zydis exposes signedness, address/relative flags, displacement offsets and sizes in decoded operands. citeturn830869search5

## AArch64

AArch64 demonstrates page-relative and paired realization semantics. LLVM LLD checks paired `ADRP + ADD` relaxation candidates and may replace the pair with `NOP + ADR` under its documented conditions. citeturn830869search7

## RISC-V

The current RISC-V linker-relaxation specification explicitly defines relocation groups, requires group-consistent relaxation, and documents `AUIPC + JALR` relaxing to `JAL`. citeturn830869search1

The current LLVM RISC-V backend checks exact JAL and conditional-branch ranges and 2-byte fixup granularity. citeturn830869search0
