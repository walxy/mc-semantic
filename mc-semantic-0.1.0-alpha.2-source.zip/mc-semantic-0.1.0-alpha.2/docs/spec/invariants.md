# M0 invariants

1. **Reference determinism** — a normalized reference has one interpretation for its supplied context.
2. **Checked expression evaluation** — address arithmetic detects overflow rather than relying on signed wraparound.
3. **Constraint validity** — a realization is valid only when all declared representability constraints pass.
4. **No silent narrowing** — no value is truncated into an encoding field without an explicit constraint check.
5. **Group consistency** — coupled groups preserve their declared dependency semantics.
6. **Internal-target mapping** — transformed internal targets resolve through the address map when a mapping is required.
7. **No fabricated mappings** — deleted/unknown/ambiguous locations are never guessed.
8. **Realization/reference consistency** — a realization claims only relationships it actually encodes.
9. **Explicit unsupported behavior** — unsupported forms return `MC_STATUS_UNSUPPORTED`.
10. **No object-format leakage** — the semantic core does not depend on ELF/COFF/Mach-O relocation identifiers.
