# Security

The core may receive hostile or malformed machine-code facts from adapters. The implementation therefore follows these rules:

- bounded parsing in adapters;
- checked integer arithmetic;
- no silent narrowing;
- explicit unresolved/ambiguous/unsupported states;
- deterministic failure;
- no process-memory APIs in the core;
- no global mutable state;
- sanitizers and fuzzing before stable release.

The project should target OpenSSF security practices and establish reproducible build/release provenance over time. SLSA v1.2 currently defines the provenance concept and approved specification for supply-chain security. citeturn830869search2turn830869search3
