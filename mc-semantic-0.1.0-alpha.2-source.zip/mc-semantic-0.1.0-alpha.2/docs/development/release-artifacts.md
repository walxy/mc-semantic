# Release artifacts

Each release should have:

| Artifact | Purpose |
|---|---|
| Git tag | immutable version identity |
| source ZIP | manual GitHub Release download |
| release notes | exact user-facing change record |
| SHA-256 | integrity verification |
| build/test record | reproducibility evidence |

## Naming

```text
mc-semantic-<version>-source.zip
```

Examples:

```text
mc-semantic-0.1.0-alpha.2-source.zip
mc-semantic-0.1.0-beta.1-source.zip
mc-semantic-1.0.0-source.zip
```

Do not put generated build directories in the archive.

## Version lock

The following must agree:

```text
VERSION
include/mc/mc_version.h
Git tag
CHANGELOG.md
release-notes/<version>.md
archive filename
```

The release helper checks the first two and generates the archive from the current Git tree.
