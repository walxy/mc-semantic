# GitHub upload procedure

Target owner: `walxy`.

The local repository is prepared so that each release can be uploaded in **two independent forms**:

1. normal Git history/tag for developers;
2. a versioned source ZIP attached manually to the GitHub Release for users who prefer an archive.

The destination repository name used by this scaffold is `mc-semantic`. The repository was not found on GitHub when checked, so it must be created before the first push.

## First push

Create an empty repository at:

`https://github.com/walxy/mc-semantic`

Do not initialize it with a README, license, or `.gitignore`; the local repository already contains them.

```sh
git remote add origin git@github.com:walxy/mc-semantic.git
git push -u origin main
git push origin --tags
```

HTTPS:

```sh
git remote add origin https://github.com/walxy/mc-semantic.git
git push -u origin main
git push origin --tags
```

## Manual source ZIP upload

Each public version gets an archive such as:

```text
mc-semantic-0.1.0-alpha.2-source.zip
```

The archive must contain source/documentation only. Never include:

- `.git/`
- `build/`
- sanitizer output
- compiler caches
- local virtual environments
- credentials/tokens

The release helper generates the archive deterministically from the Git tree.

## GitHub Release

Use the matching release tag, for example:

```text
v0.1.0-alpha.2
```

Recommended release title:

```text
MC 0.1.0-alpha.2 — Defensive Core and M0 API Corrections
```

Attach:

```text
mc-semantic-0.1.0-alpha.2-source.zip
```

and publish the prepared release notes from `release-notes/v0.1.0-alpha.2.md`.

## Why keep both Git and ZIP?

Git is the authoritative development history. The ZIP is a convenience artifact for users who want one versioned source package without cloning Git. The ZIP must always correspond exactly to the tagged tree.
