# Testing

Testing is organized in layers.

## Unit tests

Exercise deterministic core operations such as range checks, expression arithmetic and address mapping.

## Boundary tests

Every architecture adapter must test exact legal boundaries, one unit inside, one unit outside, negative/positive directions and invalid granularity.

## Differential tests

Normalize results from multiple mature implementations and compare semantic records rather than requiring byte-identical encodings.

## Negative tests

At minimum:

- overflow
- out-of-range
- invalid granularity
- unresolved target
- ambiguous target
- deleted mapping
- partial atomic-group transformation
- unsupported realization

## Regression corpus

Real upstream defects should be included as regression seeds but must be classified by the semantic layer they actually exercise. For example, current LLVM BOLT issues show stale `DW_OP_addr` values after code movement; that supports the need for address mapping plus a DWARF-specific consumer, but does not mean the address map alone rewrites DWARF. fileciteturn14file0
