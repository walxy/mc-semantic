# Git policy

## Repository identity

Recommended GitHub owner: `walxy`.

Recommended repository name for this scaffold: `mc-semantic` (availability/name collision should be checked again before publishing).

## Protected branches

`main` should contain only buildable, testable states after the initial public-development phase.

## Tags

Use annotated release tags:

```text
v0.1.0-alpha.1
v0.1.0-alpha.2
v0.1.0-beta.1
v0.1.0
...
```

## Git history

Keep research notes in `docs/`, not in commit-message archaeology. Use commits for reviewable implementation units.
