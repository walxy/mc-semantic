# Development workflow

## Branching

Use short-lived topic branches and merge only changes that have tests and documentation updates where behavior changes.

## Commit scope

Prefer atomic commits:

- one semantic change
- one test change
- one documentation change when necessary

Avoid mixing API redesign with formatting-only changes.

## Required checks

```sh
cmake -S . -B build -DMC_BUILD_TESTS=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
mkdocs build --strict
```

## Research changes

Any change to the semantic model should update:

1. specification text;
2. architecture mapping;
3. conformance corpus;
4. implementation;
5. regression tests;
6. changelog/roadmap entry.
