# Release checklist

## Correctness

- [ ] C11 build passes with warnings enabled.
- [ ] Unit tests pass.
- [ ] Sanitizer build passes.
- [ ] Boundary and negative corpus passes.
- [ ] Architecture adapters have specification traceability.

## API

- [ ] Public API is documented.
- [ ] Breaking changes are explicitly versioned.
- [ ] No accidental object-format leakage.
- [ ] Ownership/lifetime rules are explicit.

## Documentation

- [ ] `mkdocs build --strict` passes.
- [ ] README and FAQ match the implementation.
- [ ] Changelog matches the release.

## Security/reproducibility

- [ ] Security policy reviewed.
- [ ] Fuzzing baseline recorded where applicable.
- [ ] Release provenance generated for the public release pipeline.
- [ ] Release tag is immutable after publication.
