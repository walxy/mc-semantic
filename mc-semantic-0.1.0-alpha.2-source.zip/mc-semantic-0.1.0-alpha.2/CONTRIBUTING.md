# Contributing

1. Read `docs/spec/` before changing semantic behavior.
2. Keep the core architecture-neutral.
3. Add tests for every semantic change.
4. Update documentation for public API changes.
5. Record deliberate behavior changes in `CHANGELOG.md`.
6. Do not add object-format relocation IDs to the core.
7. Do not add process-memory APIs to the core.
8. Run CMake build/tests and `mkdocs build --strict` before submitting a change.
