/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"
#include <assert.h>

static void test_signed_width_boundaries(void);

void test_constraints(void) {
    const mc_constraint c = {
        .width = 8U,
        .granularity = 1U,
        .min = -128,
        .max = 127,
        .signed_value = true
    };
    assert(mc_constraint_check(&c, 127) == MC_STATUS_OK);
    assert(mc_constraint_check(&c, -128) == MC_STATUS_OK);
    assert(mc_constraint_check(&c, 128) == MC_STATUS_OUT_OF_RANGE);
    assert(mc_constraint_check(&c, -129) == MC_STATUS_OUT_OF_RANGE);
    test_signed_width_boundaries();
}

static void test_signed_width_boundaries(void) {
    const mc_constraint c63 = {
        .width = 63U, .granularity = 1U,
        .min = INT64_MIN, .max = INT64_MAX, .signed_value = true
    };
    assert(mc_constraint_check(&c63, INT64_C(4611686018427387903)) == MC_STATUS_OK);
    assert(mc_constraint_check(&c63, INT64_C(4611686018427387904)) == MC_STATUS_OUT_OF_RANGE);

    const mc_constraint c64 = {
        .width = 64U, .granularity = 1U,
        .min = INT64_MIN, .max = INT64_MAX, .signed_value = true
    };
    assert(mc_constraint_check(&c64, INT64_MIN) == MC_STATUS_OK);
    assert(mc_constraint_check(&c64, INT64_MAX) == MC_STATUS_OK);
}

