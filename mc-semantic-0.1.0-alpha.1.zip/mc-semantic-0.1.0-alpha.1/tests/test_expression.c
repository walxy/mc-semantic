/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"
#include <assert.h>

void test_expressions(void) {
    int64_t value = 0;

    const mc_expression pc = {
        .kind = MC_EXPR_PC_RELATIVE,
        .addend = 0,
        .page_shift = 0U
    };
    assert(mc_expression_eval(&pc, 1000U, 1100U, &value) == MC_STATUS_OK);
    assert(value == 100);
    assert(mc_expression_eval(&pc, 1100U, 1000U, &value) == MC_STATUS_OK);
    assert(value == -100);

    const mc_expression page = {
        .kind = MC_EXPR_PAGE_RELATIVE,
        .addend = 0,
        .page_shift = 12U
    };
    assert(mc_expression_eval(&page, 0x1000U, 0x9000U, &value) == MC_STATUS_OK);
    assert(value == 8);

    const mc_expression page_addend = {
        .kind = MC_EXPR_PAGE_RELATIVE,
        .addend = -1,
        .page_shift = 12U
    };
    assert(mc_expression_eval(&page_addend, 0x9000U, 0x9000U, &value) == MC_STATUS_OK);
    assert(value == -1);
}
