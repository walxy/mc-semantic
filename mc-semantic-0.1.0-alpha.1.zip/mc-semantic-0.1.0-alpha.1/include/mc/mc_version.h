/* SPDX-License-Identifier: MIT */
#ifndef MC_VERSION_H
#define MC_VERSION_H

#define MC_VERSION_MAJOR 0
#define MC_VERSION_MINOR 1
#define MC_VERSION_PATCH 0
#define MC_VERSION_PRERELEASE "alpha.1"
#define MC_VERSION_STRING "0.1.0-alpha.1"

#endif
