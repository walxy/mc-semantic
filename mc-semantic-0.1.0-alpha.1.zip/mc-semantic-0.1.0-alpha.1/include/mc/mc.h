/* SPDX-License-Identifier: MIT */
#ifndef MC_H
#define MC_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "mc_version.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    MC_ARCH_UNKNOWN = 0,
    MC_ARCH_X86_64,
    MC_ARCH_AARCH64,
    MC_ARCH_RISCV64
} mc_arch;

typedef struct {
    mc_arch architecture;
    uint32_t mode;
    uint32_t isa_revision;
} mc_context;

typedef struct {
    uint64_t address;
    uint64_t size;
} mc_region;

typedef enum {
    MC_TARGET_ADDRESS = 0,
    MC_TARGET_SYMBOL,
    MC_TARGET_SECTION_OFFSET,
    MC_TARGET_EXTERNAL,
    MC_TARGET_OPAQUE
} mc_target_kind;

typedef enum {
    MC_RESOLUTION_UNKNOWN = 0,
    MC_RESOLUTION_RESOLVED,
    MC_RESOLUTION_UNRESOLVED,
    MC_RESOLUTION_AMBIGUOUS
} mc_resolution_state;

typedef struct {
    mc_target_kind kind;
    mc_resolution_state state;
    uint64_t address;
    const char *name;
} mc_target;

typedef enum {
    MC_EXPR_PC_RELATIVE = 0,
    MC_EXPR_PAGE_RELATIVE,
    MC_EXPR_SECTION_RELATIVE
} mc_expression_kind;

typedef struct {
    mc_expression_kind kind;
    int64_t addend;
    uint32_t page_shift;
} mc_expression;

typedef struct {
    mc_region source;
    mc_target target;
    mc_expression expression;
    mc_resolution_state state;
} mc_reference;

typedef enum {
    MC_GROUP_LINKED = 0,
    MC_GROUP_ATOMIC
} mc_group_coupling;

typedef uint32_t mc_reference_id;

typedef struct {
    const mc_reference_id *members;
    size_t member_count;
    mc_group_coupling coupling;
} mc_reference_group;

typedef struct {
    uint32_t width;
    uint32_t granularity;
    int64_t min;
    int64_t max;
    bool signed_value;
} mc_constraint;

typedef struct {
    const uint32_t *instruction_ids;
    size_t instruction_count;
    const mc_constraint *constraints;
    size_t constraint_count;
} mc_realization;

typedef enum {
    MC_MAP_MOVED = 0,
    MC_MAP_RESIZED,
    MC_MAP_DELETED,
    MC_MAP_CREATED
} mc_map_state;

typedef struct {
    mc_region old_region;
    mc_region new_region;
    mc_map_state state;
} mc_map_entry;

typedef struct {
    mc_map_entry *entries;
    size_t size;
    size_t capacity;
} mc_address_map;

typedef enum {
    MC_STATUS_OK = 0,
    MC_STATUS_INVALID,
    MC_STATUS_UNRESOLVED,
    MC_STATUS_AMBIGUOUS,
    MC_STATUS_OUT_OF_RANGE,
    MC_STATUS_UNSUPPORTED,
    MC_STATUS_CONFLICT
} mc_status;

mc_status mc_constraint_check(const mc_constraint *constraint, int64_t value);
mc_status mc_expression_eval(const mc_expression *expression,
                             uint64_t base_address,
                             uint64_t target_address,
                             int64_t *result);
const char *mc_status_name(mc_status status);

void mc_address_map_init(mc_address_map *map);
void mc_address_map_destroy(mc_address_map *map);
mc_status mc_address_map_add(mc_address_map *map, mc_map_entry entry);
mc_status mc_address_map_translate_exact(const mc_address_map *map,
                                         uint64_t old_address,
                                         uint64_t *new_address);

#ifdef __cplusplus
}
#endif

#endif
