/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"

#include <stdlib.h>

void mc_address_map_init(mc_address_map *map) {
    if (map == NULL) return;
    map->entries = NULL;
    map->size = 0U;
    map->capacity = 0U;
}

void mc_address_map_destroy(mc_address_map *map) {
    if (map == NULL) return;
    free(map->entries);
    map->entries = NULL;
    map->size = 0U;
    map->capacity = 0U;
}

static bool region_end_valid(mc_region region) {
    return region.size == 0U || region.address <= UINT64_MAX - (region.size - 1U);
}

mc_status mc_address_map_add(mc_address_map *map, mc_map_entry entry) {
    if (map == NULL || (entry.old_region.size == 0U && entry.state != MC_MAP_CREATED) ||
        !region_end_valid(entry.old_region) || !region_end_valid(entry.new_region)) {
        return MC_STATUS_INVALID;
    }
    if (map->size == map->capacity) {
        const size_t new_capacity = map->capacity == 0U ? 8U : map->capacity * 2U;
        mc_map_entry *grown = realloc(map->entries, new_capacity * sizeof(*grown));
        if (grown == NULL) return MC_STATUS_UNSUPPORTED;
        map->entries = grown;
        map->capacity = new_capacity;
    }
    map->entries[map->size++] = entry;
    return MC_STATUS_OK;
}

mc_status mc_address_map_translate_exact(const mc_address_map *map,
                                         uint64_t old_address,
                                         uint64_t *new_address) {
    if (map == NULL || new_address == NULL) return MC_STATUS_INVALID;

    for (size_t i = 0U; i < map->size; ++i) {
        const mc_map_entry *entry = &map->entries[i];
        const uint64_t start = entry->old_region.address;
        const uint64_t size = entry->old_region.size;
        if (old_address < start || old_address - start >= size) continue;

        if (entry->state == MC_MAP_DELETED) return MC_STATUS_UNSUPPORTED;
        if (entry->state == MC_MAP_CREATED) continue;
        if (entry->state != MC_MAP_MOVED ||
            entry->old_region.size != entry->new_region.size) {
            return MC_STATUS_AMBIGUOUS;
        }

        const uint64_t offset = old_address - start;
        *new_address = entry->new_region.address + offset;
        return MC_STATUS_OK;
    }

    return MC_STATUS_UNSUPPORTED;
}
