/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"

#include <limits.h>
#include <stdbool.h>

static bool add_u64_i64_checked(uint64_t value, int64_t addend, uint64_t *out) {
    if (addend >= 0) {
        const uint64_t uadd = (uint64_t)addend;
        if (value > UINT64_MAX - uadd) return false;
        *out = value + uadd;
        return true;
    }

    const uint64_t magnitude = (uint64_t)(-(addend + 1)) + 1U;
    if (value < magnitude) return false;
    *out = value - magnitude;
    return true;
}

static bool sub_u64_to_i64_checked(uint64_t lhs, uint64_t rhs, int64_t *out) {
    if (lhs >= rhs) {
        const uint64_t d = lhs - rhs;
        if (d > (uint64_t)INT64_MAX) return false;
        *out = (int64_t)d;
        return true;
    }

    const uint64_t d = rhs - lhs;
    if (d > (uint64_t)INT64_MAX + 1U) return false;
    if (d == (uint64_t)INT64_MAX + 1U) {
        *out = INT64_MIN;
        return true;
    }
    *out = -(int64_t)d;
    return true;
}

mc_status mc_expression_eval(const mc_expression *expression,
                             uint64_t base_address,
                             uint64_t target_address,
                             int64_t *result) {
    if (expression == NULL || result == NULL) {
        return MC_STATUS_INVALID;
    }

    uint64_t adjusted_target = target_address;
    switch (expression->kind) {
    case MC_EXPR_PC_RELATIVE:
        if (!add_u64_i64_checked(target_address, expression->addend, &adjusted_target)) {
            return MC_STATUS_OUT_OF_RANGE;
        }
        if (!sub_u64_to_i64_checked(adjusted_target, base_address, result)) {
            return MC_STATUS_OUT_OF_RANGE;
        }
        return MC_STATUS_OK;

    case MC_EXPR_PAGE_RELATIVE: {
        if (expression->page_shift >= 63U) {
            return MC_STATUS_INVALID;
        }
        if (!add_u64_i64_checked(target_address, expression->addend, &adjusted_target)) {
            return MC_STATUS_OUT_OF_RANGE;
        }
        const uint64_t page_size = UINT64_C(1) << expression->page_shift;
        const uint64_t base_page = base_address / page_size;
        const uint64_t target_page = adjusted_target / page_size;
        if (!sub_u64_to_i64_checked(target_page, base_page, result)) {
            return MC_STATUS_OUT_OF_RANGE;
        }
        return MC_STATUS_OK;
    }

    case MC_EXPR_SECTION_RELATIVE:
        return MC_STATUS_UNSUPPORTED;

    default:
        return MC_STATUS_INVALID;
    }
}
