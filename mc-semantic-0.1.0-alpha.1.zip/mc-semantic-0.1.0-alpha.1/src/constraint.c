/* SPDX-License-Identifier: MIT */
#include "mc/mc.h"

mc_status mc_constraint_check(const mc_constraint *constraint, int64_t value) {
    if (constraint == NULL || constraint->width == 0U ||
        constraint->width > 64U || constraint->granularity == 0U) {
        return MC_STATUS_INVALID;
    }

    if (value < constraint->min || value > constraint->max) {
        return MC_STATUS_OUT_OF_RANGE;
    }

    const int64_t granularity = (int64_t)constraint->granularity;
    if ((value % granularity) != 0) {
        return MC_STATUS_OUT_OF_RANGE;
    }

    if (constraint->signed_value && constraint->width < 64U) {
        const unsigned shift = constraint->width - 1U;
        const int64_t signed_min = -(INT64_C(1) << shift);
        const int64_t signed_max = (INT64_C(1) << shift) - 1;
        if (value < signed_min || value > signed_max) {
            return MC_STATUS_OUT_OF_RANGE;
        }
    }

    return MC_STATUS_OK;
}
