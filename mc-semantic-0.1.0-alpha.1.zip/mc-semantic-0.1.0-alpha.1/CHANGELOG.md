# Changelog

## [0.1.0-alpha.1] - 2026-08-30

### Added

- Initial C11 semantic core scaffold.
- Checked representability constraints.
- Small normalized address-expression evaluator.
- Basic semantic address map.
- Material for MkDocs documentation from project start.
- CMake build, tests and GitHub Actions CI.

### Explicitly not included

- architecture adapters
- binary relocation
- transformation planning
- process-memory patching
- DWARF/CFI/ABI rewriting
