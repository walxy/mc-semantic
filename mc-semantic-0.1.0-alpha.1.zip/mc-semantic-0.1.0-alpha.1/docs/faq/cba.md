# CBA — code-base architecture comparison

| Option | Core implementation | Assembly use | Portability | Auditability | Decision |
|---|---|---|---|---|---|
| A | 100% assembly | pervasive | low | difficult | **Reject** |
| B | Portable C11 | fixtures only | high | high | **Preferred M0** |
| C | C11 core + small architecture adapters | fixtures and rare low-level probes | high | high | **Preferred long-term** |

## Does MC need to be fully written in assembly?

**No.** The semantic core is better implemented in C11 because its dominant work is checked integer arithmetic, range/granularity validation, typed location bookkeeping and deterministic state handling. GCC documents substantially complete C11 support with `-std=c11`. citeturn787336search0turn787336search1

Assembly remains valuable for exact architecture fixtures and later ABI/CFI experiments, but it should not be the implementation language for the portable semantic core.

## Why C11 rather than C++ or Rust?

This is a scope decision, not a claim that C11 is universally superior. A tiny C ABI makes the core easy to embed into C, C++, Rust, Python FFI, kernels and firmware. Rust/C++ bindings can be added later without changing the semantic model.
