# Development release roadmap

## `0.1.0-alpha.1` — Core prototype

**Users can use:** checked constraints, normalized expression evaluation, basic address maps.

**Not included:** architecture adapters, binary relocation, transformation planning.

## `0.1.0-alpha.2` — Defensive core

Add stronger diagnostics, overlap/ordering checks, more negative tests, API documentation, sanitizer CI.

## `0.1.0-alpha.3` — x86-64 experimental adapter

Add a narrowly scoped x86-64 adapter for extracting relative references from selected instruction classes; use existing engines rather than implementing an x86 decoder.

## `0.1.0-alpha.4` — AArch64 experimental adapter

Add selected `B`, `BL`, conditional/test branches, `ADR`, `ADRP` reference normalization.

## `0.1.0-alpha.5` — RISC-V experimental adapter

Add selected RV64 `JAL`, branches, `AUIPC`-based paired references and group metadata.

## `0.1.0-beta.1` — Cross-ISA M0

Freeze the semantic model for the M0 experiment; publish the initial conformance corpus and known limitations.

## `0.1.0-beta.2` — Differential conformance

Compare selected LLVM/GNU/Iced/Zydis-derived observations and report semantic equivalence/disagreement.

## `0.1.0-beta.3` — Transformation planning prototype

Add `MCReferenceChange`, `MCRewrite`, and an experimental `MCTransformPlan` without promising stable production transformations.

## `0.1.0-rc.1` — Release candidate

No known critical memory-safety defects; deterministic tests, sanitizer/fuzzing baseline, strict docs build, API review.

## `0.1.0` — First recommended developer release

Stable enough for specialist developers to build research/integration tooling on the documented M0 API. It is **not** a general-purpose binary rewriting engine.

## `0.2.0` — First useful integration release

Potentially add production-quality adapters for one or more engines, improved mapping semantics, and a small transformation API if the M0 evidence supports it.

## `0.3.0` — Controlled transformations

Potentially support a defined subset of branch/PC-relative realization rewrites with explicit plans/reports.

## `0.4.0` — Conformance expansion

Broader architecture/engine coverage and substantially larger regression corpus.

## `0.5.0` — Patch-window utility

A separate high-level utility may become usable for instruction-complete patch windows; still no process-memory manipulation in core.

## `0.6.0` — Metadata integration experiments

Optional DWARF/CFI adapters only; never move metadata parsing into the semantic core.

## `0.7.0` — Security/assurance maturity

Fuzzing corpus, sanitizers, reproducible release artifacts, provenance and stronger project-security controls.

## `0.8.0` — API hardening

Reduce experimental escape hatches; tighten ownership, lifetime and error semantics.

## `0.9.0` — Feature freeze candidate

Only correctness/security/documentation fixes expected before `1.0.0`.

## `1.0.0` — Stable semantic core

Release only after cross-ISA conformance, API audit, compatibility policy, fuzzing and documentation meet the project's defined acceptance gates.
