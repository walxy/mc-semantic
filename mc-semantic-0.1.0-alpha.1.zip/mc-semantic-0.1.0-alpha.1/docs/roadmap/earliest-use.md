# Earliest possible user availability

There are three different meanings of “usable”.

| Level | Earliest realistic milestone | What users can do |
|---|---|---|
| Research use | **`0.1.0-alpha.1`** | Use checked constraints, expression evaluation and basic address mapping in experiments |
| Specialist integration | **`0.1.0-beta.1`** | Consume normalized x86-64/AArch64/RISC-V reference facts through experimental adapters |
| Recommended developer use | **`0.1.0`** | Build tooling on the documented M0 semantic API |
| Production transformation use | **No earlier than `0.2.x`–`0.3.x`** | Only after transformation planning, conformance and security gates pass |
| General-purpose binary rewriting | **Not promised by this roadmap** | The project deliberately does not aim to replace established rewriters/linkers |

So the **earliest possible user-visible release is `0.1.0-alpha.1`**, but the earliest release I would recommend to external specialist users is `0.1.0-beta.1` or later, after the cross-ISA M0 corpus is complete.

The distinction matters: the early release is useful software, but it is not yet a production binary transformation engine.

## Practical recommendation

For the current implementation, “user usable” means an engineer can build the library, link against the static library, and use the checked primitives. It does **not** yet mean “drop an arbitrary binary into MC and have it safely relocated.” That capability is later and adapter-dependent.
