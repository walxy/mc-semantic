# Source tree

```text
.
├── .github/workflows/       # CI and documentation deployment
├── cmake/                   # future CMake helpers
├── docs/                    # Material for MkDocs
│   ├── architecture/
│   ├── development/
│   ├── faq/
│   ├── guides/
│   ├── reference/
│   ├── roadmap/
│   └── spec/
├── examples/                # tiny user-facing examples
├── include/mc/              # public C11 headers
├── src/                     # core implementation
├── tests/                   # deterministic unit tests
├── CMakeLists.txt
├── LICENSE
├── README.md
└── mkdocs.yml
```

Future adapters should live outside the core implementation directory, e.g. `adapters/x86_64/`, `adapters/aarch64/`, and `adapters/riscv/`.
