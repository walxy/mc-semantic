# GitHub upload procedure

Target owner: `walxy`.

The scaffold is intentionally prepared without guessing a repository name beyond the working recommendation `mc-semantic`. Before the first push, create the destination repository under the `walxy` account and keep it empty (no README/license initialization) so local history remains authoritative.

## Push

```sh
git remote add origin git@github.com:walxy/mc-semantic.git
git push -u origin main
git push origin v0.1.0-alpha.1
```

For HTTPS:

```sh
git remote add origin https://github.com/walxy/mc-semantic.git
git push -u origin main
git push origin v0.1.0-alpha.1
```

After the first push, enable branch protection/rulesets for `main`, require CI, and enable GitHub Pages for the documentation workflow.
